import React from "react";

const Footer = () => (
  <div className="footer">
    <p>This is some content in sticky footer</p>
  </div>
);

export default Footer;