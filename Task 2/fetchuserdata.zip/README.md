# LGMVIP-Webdev-Task2

Here in this repository i have created a web application using React App.
1.i had  Created a User card grid layout having a navbar showing any brand name .

2. Add a button in the navbar saying 'Get Users', which makes an API call to get the user data

3. Use https://reqres.in/api/users?page=1 to get the data for the users information. 

4. Show a loader while the API fetches the data. 

5. Use custom CSS/SASS/styled-components. 



You can check the demo to this at : https://tarun691sharma.github.io/LGMVIP-Webdev-Task2/
